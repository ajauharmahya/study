-- dapatkan laba rata-rata dari semua produk
SELECT AVG(price-cost)
FROM items;