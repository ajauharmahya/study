-- Akses semua kolom dari tabel "purchases" 
SELECT * FROM purchases;
