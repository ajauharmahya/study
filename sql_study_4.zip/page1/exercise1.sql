-- Tambahkan data ke tabel students


-- Jangan menghapus kueri dibawah
select * from students;
INSERT INTO students (name,course)
VALUES ("Kate", "Java");