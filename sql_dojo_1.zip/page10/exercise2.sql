-- dapatkan data untuk 5 produk dengan penjualan tertinggi 
SELECT items.id, items.name, price *COUNT(*) AS "total penjualan"
FROM items
JOIN sales_records
ON items.id = sales_records.item_id
GROUP BY items.id, items.name
ORDER BY price * COUNT(*) DESC
LIMIT 5;