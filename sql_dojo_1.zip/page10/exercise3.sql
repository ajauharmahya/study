-- dapatkan semua barang dengan total penjualan yang lebih besar dari "hoodie abu-abu"
SELECT items.id, items.name, price*COUNT(*) AS "total penjualan"
FROM items
JOIN sales_records
ON items.id = sales_records.item_id
GROUP BY items.id, items.name
HAVING price*COUNT(*) > (
  SELECT price*COUNT(*)
  FROM items
  JOIN sales_records
  ON items.id = sales_records.item_id
  WHERE name = "hoodie abu-abu"
  );