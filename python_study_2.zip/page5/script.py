# Tetapkan dictionary ke variable fruits
fruits = {'apel' : 'apple', 'jeruk' : 'orange'}

# Cetak nilai dengan kunci 'jeruk'
print(fruits['jeruk'])

# Dengan menggunakan dictionary fruits, cetak 'Bahasa Inggris apel adalah ___'
print('Bahasa Inggris apel adalah ' + fruits['apel'])
