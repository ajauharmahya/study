SELECT players.name AS "nama pemain" , players.height AS "tinggi pemain"
FROM players
WHERE height > (
SELECT AVG(height)
FROM players
);